# -*- coding: utf-8 -*-
#===========================================

import os
import random
import requests
import datetime, time
import csv

from functools import wraps
from flask import Flask, request, abort, render_template, Response
from flask import json, jsonify, session, redirect, url_for
from flask import send_file

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

VER = 'V2021.07.17'

#app = Flask(__name__)
app = Flask(__name__, static_url_path='', static_folder='static')

@app.route('/')
@app.route('/test')
def test():
    local_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    return jsonify({'result':'OK', 'localtime':local_time, 'version':VER})

@app.route('/image1')
def image1():
    fn = 'image1.png'
    x = [1, 5, 7, 3, 8, 10, 2.5, 8]
    plt.plot(x)
    plt.savefig(fn)
    plt.close()
    return send_file(fn, mimetype='image/png')

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0')
